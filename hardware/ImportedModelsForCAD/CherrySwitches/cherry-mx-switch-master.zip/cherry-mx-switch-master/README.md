# cherry-mx-switch

A simple 3D model of pcb mount Cherry MX switch

![render](render.png)
